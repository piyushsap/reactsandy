import './App.css';
import { useState, useEffect } from "react";
import axios from "axios";

function App() {

  const [character,setCharacter] = useState([])
  
  useEffect(() => {
    let mounted = true;
    axios.get("https://swapi.dev/api/people/")
    .then((data)=>{
      if(mounted) {
        setCharacter(data.data.results)
      }
    })
    .then(data=>{
      console.log(character,1111,data)
    })
    return () => mounted = false;
  },[]);
  
  return (
    <div className="App">
      <span>{character.length}</span>
      {character.length > 0 &&
        <select>
          <option>All</option>
          {character.map((animal,index) => (
            <option value={index} key={index}>{animal.name}</option>
          ))}
        </select>
      }
    </div>
  );
}

export default App;
